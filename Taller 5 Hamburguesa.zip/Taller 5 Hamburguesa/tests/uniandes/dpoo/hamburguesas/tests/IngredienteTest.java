package uniandes.dpoo.hamburguesas.tests;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import uniandes.dpoo.hamburguesas.mundo.Ingrediente;

public class IngredienteTest
{
    private Ingrediente componenteExtra;

    @BeforeEach
    void inicializar() throws Exception
    {
        componenteExtra = new Ingrediente("tomate", 1000);
    }

    @AfterEach
    void limpiar() throws Exception
    {
    }

    @Test
    void comprobarNombre()
    {
        assertEquals("tomate", componenteExtra.getNombre(), "El nombre del componente no coincide");
    }

    @Test
    void comprobarCostoAdicional()
    {
        assertEquals(1000, componenteExtra.getCostoAdicional(), "El costo adicional no coincide");
    }
}
