package uniandes.dpoo.hamburguesas.tests;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import uniandes.dpoo.hamburguesas.mundo.ProductoMenu;

class ProductoMenuTest {

    @Test
    public void testGetNombre() {
        ProductoMenu producto = new ProductoMenu("Hamburguesa Sencilla", 15000);
        assertEquals("Hamburguesa Sencilla", producto.getNombre());
    }

    @Test
    public void testGetPrecio() {
        ProductoMenu producto = new ProductoMenu("Papas Fritas", 5000);
        assertEquals(5000, producto.getPrecio());
    }
    @Test
    public void testGenerarTextoFactura() {
        ProductoMenu producto = new ProductoMenu("Gaseosa", 3000);

        StringBuilder facturaEsperada = new StringBuilder();
        facturaEsperada.append(producto.getNombre()).append("\n")
                       .append("            ").append(producto.getPrecio()).append("\n");

        assertEquals(facturaEsperada.toString(), producto.generarTextoFactura());
    }

}
