package uniandes.dpoo.hamburguesas.tests;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import uniandes.dpoo.hamburguesas.mundo.Pedido;
import uniandes.dpoo.hamburguesas.mundo.ProductoMenu;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;

class PedidoTest {

    private Pedido pedido;

    @BeforeEach
    void setUp() {
        pedido = new Pedido("Cliente Test", "Dirección Test");
    }

    @Test
    void testInicializacionPedido() {
        assertEquals("Cliente Test", pedido.getNombreCliente());
        assertEquals("Dirección Test", pedido.getDireccionCliente());
        assertEquals(3, pedido.getIdPedido());
    }

    @Test
    void testAgregarProducto() {
        ProductoMenu producto = new ProductoMenu("Hamburguesa Sencilla", 5000);
        pedido.agregarProducto(producto);
        
        assertEquals(1, pedido.getProductos().size());
        assertTrue(pedido.getProductos().contains(producto));
    }

    @Test
    void testCalcularPrecioNetoPedido() {
        ProductoMenu producto1 = new ProductoMenu("Hamburguesa Sencilla", 5000);
        ProductoMenu producto2 = new ProductoMenu("Papas Fritas", 3000);
        pedido.agregarProducto(producto1);
        pedido.agregarProducto(producto2);
        
        int precioNetoEsperado = 5000 + 3000;
        assertEquals(precioNetoEsperado, pedido.getPrecioNetoPedido());
    }

    @Test
    void testCalcularPrecioIVAPedido() {
        ProductoMenu producto1 = new ProductoMenu("Hamburguesa Sencilla", 5000);
        ProductoMenu producto2 = new ProductoMenu("Papas Fritas", 3000);
        pedido.agregarProducto(producto1);
        pedido.agregarProducto(producto2);
        
        int ivaEsperado = (int) (pedido.getPrecioNetoPedido() * 0.19);
        assertEquals(ivaEsperado, pedido.getPrecioIVAPedido());
    }

    @Test
    void testCalcularPrecioTotalPedido() {
        ProductoMenu producto1 = new ProductoMenu("Hamburguesa Sencilla", 5000);
        ProductoMenu producto2 = new ProductoMenu("Papas Fritas", 3000);
        pedido.agregarProducto(producto1);
        pedido.agregarProducto(producto2);
        
        int totalEsperado = pedido.getPrecioNetoPedido() + pedido.getPrecioIVAPedido();
        assertEquals(totalEsperado, pedido.getPrecioTotalPedido());
    }

    @Test
    void testGenerarTextoFactura() {
        ProductoMenu producto1 = new ProductoMenu("Hamburguesa Sencilla", 5000);
        ProductoMenu producto2 = new ProductoMenu("Papas Fritas", 3000);
        pedido.agregarProducto(producto1);
        pedido.agregarProducto(producto2);
        
        String factura = pedido.generarTextoFactura();
        
        assertTrue(factura.contains("Cliente: Cliente Test"));
        assertTrue(factura.contains("Dirección: Dirección Test"));
        assertTrue(factura.contains("Hamburguesa Sencilla"));
        assertTrue(factura.contains("Papas Fritas"));
        assertTrue(factura.contains("Precio Neto:"));
        assertTrue(factura.contains("IVA:"));
        assertTrue(factura.contains("Precio Total:"));
    }

    @Test
    void testGuardarFactura() throws IOException {
        File archivo = new File("factura_test.txt");
        
        try {
            pedido.agregarProducto(new ProductoMenu("Hamburguesa Sencilla", 5000));
            pedido.guardarFactura(archivo);

            assertTrue(archivo.exists());
        } finally {
            // Limpieza del archivo generado durante la prueba
            archivo.delete();
        }
    }

    @Test
    void testGuardarFacturaArchivoNoEncontrado() {
        File archivo = new File("/ruta/invalida/factura_test.txt");
        
        Exception exception = assertThrows(FileNotFoundException.class, () -> {
            pedido.guardarFactura(archivo);
        });
        
        assertNotNull(exception.getMessage());
    }
}