package uniandes.dpoo.hamburguesas.tests;

import static org.junit.jupiter.api.Assertions.*;

import java.util.ArrayList;

import org.junit.jupiter.api.Test;

import uniandes.dpoo.hamburguesas.mundo.Combo;
import uniandes.dpoo.hamburguesas.mundo.ProductoMenu;

class ComboTest {

    @Test
    public void comprobarNombreCombo() {
        ArrayList<ProductoMenu> productos = new ArrayList<>();
        Combo paquete = new Combo("Combo Especial", 0.2, productos);
        assertEquals("Combo Especial", paquete.getNombre());
    }

    @Test
    public void comprobarCalculoPrecio() {
        ProductoMenu item1 = new ProductoMenu("hamburguesa", 15000);
        ProductoMenu item2 = new ProductoMenu("papas fritas", 5000);
        ArrayList<ProductoMenu> productos = new ArrayList<>();
        productos.add(item1);
        productos.add(item2);

        Combo paquete = new Combo("combo familiar", 0.2, productos);

        int precioEsperado = (int) ((15000 + 5000) * 0.2);
        int precioObtenido = paquete.getPrecio();

        assertEquals(precioEsperado, precioObtenido);
    }

    @Test
    public void testGenerarTextoFactura() {
        ProductoMenu producto1 = new ProductoMenu("Hamburguesa", 15000);
        ProductoMenu producto2 = new ProductoMenu("Papas Fritas", 5000);
        ArrayList<ProductoMenu> items = new ArrayList<>();
        items.add(producto1);
        items.add(producto2);

        Combo combo = new Combo("Combo Almuerzo", 0.1, items); 

        String expectedFactura = "Combo Combo Almuerzo\n"
                            + " Descuento: 0.1\n"
                            + "            " + combo.getPrecio() + "\n";
        String actualFactura = combo.generarTextoFactura();

        assertEquals(expectedFactura, actualFactura);
    }

}
