package uniandes.dpoo.hamburguesas.tests;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import uniandes.dpoo.hamburguesas.mundo.Ingrediente;
import uniandes.dpoo.hamburguesas.mundo.ProductoAjustado;
import uniandes.dpoo.hamburguesas.mundo.ProductoMenu;

class ProductoAjustadoTest {

    @Test
    public void testGetPrecioConAgregados() {
        ProductoMenu base = new ProductoMenu("hamburguesa especial", 20000);
        ProductoAjustado productoAjustado = new ProductoAjustado(base);

        Ingrediente queso = new Ingrediente("queso", 2000);
        Ingrediente tocineta = new Ingrediente("tocineta", 2500);

        productoAjustado.agregarIngrediente(queso);
        productoAjustado.agregarIngrediente(tocineta);

        assertEquals(24500, productoAjustado.getPrecio());
    }

    @Test
    public void testGetNombre() {
        ProductoMenu base = new ProductoMenu("hamburguesa doble", 18000);
        ProductoAjustado productoAjustado = new ProductoAjustado(base);
        assertEquals("hamburguesa doble", productoAjustado.getNombre());
    }
    @Test
    public void testGenerarTextoFacturaConAjustes() {
        ProductoMenu base = new ProductoMenu("hamburguesa con queso", 16000);
        ProductoAjustado productoAjustado = new ProductoAjustado(base);

        Ingrediente cebolla = new Ingrediente("cebolla", 500);
        Ingrediente tomate = new Ingrediente("tomate", 300);

        productoAjustado.agregarIngrediente(cebolla);
        productoAjustado.eliminarIngrediente(tomate);

        StringBuilder facturaEsperada = new StringBuilder();
        facturaEsperada.append(base.getNombre()).append("\n")
                       .append("            ").append(base.getPrecio()).append("\n")
                       .append("    +").append(cebolla.getNombre())
                       .append("                ").append(cebolla.getCostoAdicional())
                       .append("    -").append(tomate.getNombre())
                       .append("            ").append(16500).append("\n");

        assertEquals(facturaEsperada.toString(), productoAjustado.generarTextoFactura());
    }
}